# Library development testing independently

For testing in isolation

```
npm run dev
```

# Building library

> From version 3.1.4 rcl-shared-components now use maven as primary way to build the library

For building the library use the following command

```
mvn package
```
